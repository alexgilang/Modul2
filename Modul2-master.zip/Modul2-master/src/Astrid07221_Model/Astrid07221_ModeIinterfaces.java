package Astrid07221_Model;
public interface Astrid07221_ModeIinterfaces { //hanya mengandung deklarasi method
 public void view();
    public int cekData (String id, String nama);   
}
