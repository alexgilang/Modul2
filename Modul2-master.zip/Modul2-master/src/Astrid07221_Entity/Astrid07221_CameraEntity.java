package Astrid07221_Entity;
public class Astrid07221_CameraEntity {
      public static String merk []  = {"Canon - 600D - Rp.80.000", "Canon - 1000D - Rp.70.000", "Canon - 500D - Rp.90.000"}; //atribut
}
